from project.clients.base_client import BaseClient


class VIPClient(BaseClient):
    def __init__(self, name):
        super().__init__(name, "VIP")

    def earning_points(self, order_amount):
        earned_points = int(order_amount // 5)
        self.points += earned_points
        return earned_points

    def display_info(self):
        print(f"Client Name: {self.name}")
        print(f"Membership Type: {self.membership_type}")
        print(f"Total Points: {self.points}")
